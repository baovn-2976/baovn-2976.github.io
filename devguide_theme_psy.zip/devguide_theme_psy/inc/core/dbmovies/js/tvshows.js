jQuery(document).ready(function($) {
    $('#generate_data_api').click(function() {
        var ids = $('#ids').get(0).value
        var dbm = DTapi.dbm + 'app/'
        var tmd = DTapi.tmd
        var dbmkey = DTapi.dbmkey
        var tmdkey = '&api_key=' + DTapi.tmdkey
        var lang = '&language=' + DTapi.lang + '&include_image_language=' + DTapi.lang + ',null'
        var genres = DTapi.genres
        var upload = DTapi.upload
        var pda = DTapi.pda
        var append = '?append_to_response=images,trailers'
        $('#api_table').addClass("hidden_api")
        $('#loading_api').html('<p><span class="spinner"></span> ' + DTapi.loading + '</p>')
        if (pda == 1) {

                             $.getJSON(tmd + ids + append + lang + tmdkey, function(tmddata) {
                                var valPlo = "";
                                var valImg = "";
                                var valBac = "";
                                var valupimg = "";
                                $('#loading_api').html('')
                                $('#api_table').removeClass("hidden_api")
                                $.each(tmddata, function(key, val) {
                                    $('input[name=' + key + ']').val(val);
                                    $('#message').remove();
                                    $("#verificador").show();
                                    if (key == "name") {
                                        $('label#title-prompt-text').addClass('screen-reader-text');
                                        $('input[name=post_title]').val(val);
                                    }
                                    if (key == "vote_count") {
                                        $('#imdbVotes').val(val);
                                    }
                                    if (key == "vote_average") {
                                        $('#imdbRating').val(val);
                                    }
                                    if (key == "overview") {
                                        if (typeof tinymce != "undefined") {
                                            var editor = tinymce.get('content');
                                            if (editor && editor instanceof tinymce.Editor) {
                                                editor.setContent(val);
                                                editor.save({
                                                    no_events: true
                                                });
                                            } else {
                                                $('textarea#content').val(val);
                                            }
                                        }
                                    }
                                    if (key == "poster_path") {
                                        $('input[name="dt_poster"]').val(val);
                                    }
                                    if (key == "backdrop_path") {
                                        $('input[name="dt_backdrop"]').val(val);
                                    }
                                    if (key == "poster_path") {
                                        valupimg += "https://image.tmdb.org/t/p/w500" + val + "";
                                        if (1 == upload) {
                                            if (DTapi.post != 'edit') {
                                                $('#postimagediv p').html("<ul><li><img class='dt_poster_preview' src='" + valupimg + "'/> </li></ul>");
                                            }
                                        }
                                    }
                                    if (key == "images") {
                                        var imgt = "";
                                        $.each(tmddata.images.backdrops, function(i, item) {
                                            if (i > 9) return false;
                                            imgt += item.file_path + "\n";
                                        });
                                        $('textarea[name="imagenes"]').val(imgt);
                                    }
                                    if (key == "first_air_date") {
                                        $('#new-tag-dtyear').val(val.slice(0, 4));
                                    }
                                    if (key == "created_by") {
                                        var crea = "";
                                        var creai = "";
                                        $.each(tmddata.created_by, function(i, item) {
                                            crea += item.name + ",";
                                            creai += "[" + item.profile_path + ";" + item.name + "]";
                                        });
                                        $('#new-tag-dtcreator').val(crea);
                                        $('#dt_creator').val(creai);
                                    }
                                    if (key == "production_companies") {
                                        var pro = "";
                                        $.each(tmddata.production_companies, function(i, item) {
                                            pro += item.name + ",";
                                        });
                                        $('#new-tag-dtstudio').val(pro);
                                    }
                                    if (key == "networks") {
                                        var net = "";
                                        $.each(tmddata.networks, function(i, item) {
                                            net += item.name + ",";
                                        });
                                        $('#new-tag-dtnetworks').val(net);
                                    }
                                    $.getJSON(tmd + ids + "/credits?" + tmdkey, function(tmddata) {
                                        $.each(tmddata, function(key, val) {
                                            if (key == "cast") {
                                                var valCast = "";
                                                var valdert = "";
                                                $.each(tmddata.cast, function(i, item) {
                                                    if (i > 9) return false;
                                                    valCast += "" + item.name + ", ";
                                                    valdert += "[" + item.profile_path + ";" + item.name + "," + item.character + "]";
                                                });
                                                $('#new-tag-dtcast').val(valCast);
                                                $('#dt_cast').val(valdert);
                                            }
                                        });
                                    });
                                    $.getJSON(tmd + ids + '/videos?language=' + DTapi.lang + tmdkey, function(tmdbdata) {
                                        $.each(tmdbdata, function(key, val) {
                                            var youtube = "";
                                            $.each(tmdbdata.results, function(i, item) {
                                                if (i > 0) return false;
                                                youtube += "[" + item.key + "]";
                                            });
                                            $('input[name="youtube_id"]').val(youtube);
                                        });
                                    });
                                });
                            });


        }
    });
});
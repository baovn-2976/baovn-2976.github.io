<?php if($default = get_option('movsmodule') == "true") {?>
<?php include_once 'default.php'; ?>	
<?php } else {?>
<script>$(document).ready(function(){$("#lmtab1").click(function(){$("#latestmov_cat").attr("href","<?php bloginfo('url');?>/<?php echo get_option('tab1_cat');?>")}),$("#lmtab2").click("hide.bs.modal",function(){$("#latestmov_cat").attr("href","<?php bloginfo('url');?>/?cat=<?php echo get_option('tab2_cat');?>")}),$("#lmtab3").click(function(){$("#latestmov_cat").attr("href","<?php bloginfo('url');?>/?cat=<?php echo get_option('tab3_cat');?>")}),$("#lmtab4").click(function(){$("#latestmov_cat").attr("href","<?php bloginfo('url');?>/?cat=<?php echo get_option('tab4_cat');?>")}),$("#lmtab5").click(function(){$("#latestmov_cat").attr("href","<?php bloginfo('url');?>/?cat=<?php echo get_option('tab5_cat');?>")}),$("#lmtab6").click(function(){$("#latestmov_cat").attr("href","<?php bloginfo('url');?>/?cat=<?php echo get_option('tab6_cat');?>")}),$("#lmtab7").click(function(){$("#latestmov_cat").attr("href","<?php bloginfo('url');?>/?cat=<?php echo get_option('tab7_cat');?>")})});</script>
<div class="movies-list-wrap mlw-latestmovie">
<div class="ml-title">
<span class="pull-left"><?php if($title = get_option('latestmov_title')){echo $title;} else{'Latest Movies';} ?> <i class="fa fa-chevron-right ml10"></i></span>
<a id="latestmov_cat" href="<?php bloginfo('url');?>/<?php echo get_option('tab1_cat');?>" class="pull-right cat-more"><?php _e('View more »', 'psythemes'); ?></a>
<ul id="latestmov-nav" role="tablist" class="nav nav-tabs">
<?php $active = get_option('tab1'); if ($active == "true") { ?><li class="active"><a id="lmtab1" data-toggle="tab" role="tab" href="#mov-tab1" aria-expanded="false"><?php echo get_option('tab1_title'); ?></a></li><?php }?>
<?php $active = get_option('tab2'); if ($active == "true") { ?><li><a id="lmtab2" data-toggle="tab" role="tab" href="#mov-tab2" aria-expanded="false"><?php echo get_option('tab2_title'); ?></a></li><?php }?>
<?php $active = get_option('tab3'); if ($active == "true") { ?><li><a id="lmtab3" data-toggle="tab" role="tab" href="#mov-tab3" aria-expanded="false"><?php echo get_option('tab3_title'); ?></a></li><?php }?>
<?php $active = get_option('tab4'); if ($active == "true") { ?><li><a id="lmtab4" data-toggle="tab" role="tab" href="#mov-tab4" aria-expanded="false"><?php echo get_option('tab4_title'); ?></a></li><?php }?>
<?php $active = get_option('tab5'); if ($active == "true") { ?><li><a id="lmtab5" data-toggle="tab" role="tab" href="#mov-tab5" aria-expanded="false"><?php echo get_option('tab5_title'); ?></a></li><?php }?>
<?php $active = get_option('tab6'); if ($active == "true") { ?><li><a id="lmtab6" data-toggle="tab" role="tab" href="#mov-tab6" aria-expanded="false"><?php echo get_option('tab6_title'); ?></a></li><?php }?>
<?php $active = get_option('tab7'); if ($active == "true") { ?><li><a id="lmtab7" data-toggle="tab" role="tab" href="#mov-tab7" aria-expanded="false"><?php echo get_option('tab7_title'); ?></a></li><?php }?>
</ul>
<div class="clearfix"></div>
</div>
<div id="latestmov-cont" class="tab-content">

<?php $active = get_option('tab1'); if ($active == "true") { ?>
<div id="mov-tab1" class="movies-list movies-list-full tab-pane in fade active">
<div id="content-box">
<?php include_once 'tab1.php'; ?>	
</div>
<div class="clearfix"></div>
</div>
<?php }?>


<?php $active = get_option('tab2'); if ($active == "true") { ?>
<div id="mov-tab2" class="movies-list movies-list-full tab-pane in fade">
<div id="content-box">
<?php include_once 'tab2.php'; ?>	
</div>
<div class="clearfix"></div>
</div>
<?php }?>


<?php $active = get_option('tab3'); if ($active == "true") { ?>   
<div id="mov-tab3" class="movies-list movies-list-full tab-pane in fade">
<div id="content-box">
<?php include_once 'tab3.php'; ?>
</div>
<div class="clearfix"></div>
</div>
<?php }?>


<?php $active = get_option('tab4'); if ($active == "true") { ?>
<div id="mov-tab4" class="movies-list movies-list-full tab-pane in fade">
<div id="content-box">
<?php include_once 'tab4.php'; ?>
</div>
<div class="clearfix"></div>
</div>
<?php }?>


<?php $active = get_option('tab5'); if ($active == "true") { ?>
<div id="mov-tab5" class="movies-list movies-list-full tab-pane in fade">
<div id="content-box">
<?php include_once 'tab5.php'; ?>
</div>
<div class="clearfix"></div>
</div>
<?php }?>


<?php $active = get_option('tab6'); if ($active == "true") { ?>
<div id="mov-tab6" class="movies-list movies-list-full tab-pane in fade">
<div id="content-box">
<?php include_once 'tab6.php'; ?>
</div>
<div class="clearfix"></div>
</div>
<?php }?>


<?php $active = get_option('tab7'); if ($active == "true") { ?>
<div id="mov-tab7" class="movies-list movies-list-full tab-pane in fade">
<div id="content-box">
<?php include_once 'tab7.php'; ?>
</div>
<div class="clearfix"></div>
</div>
<?php }?>
</div>
</div>
<?php }?>
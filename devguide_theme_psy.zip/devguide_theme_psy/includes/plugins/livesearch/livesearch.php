<?php ${"GLOBALS"}["ytbxvft"]="site2";
${"GLOBALS"}["refdrxck"]="site";
${"GLOBALS"}["welveywdxpsx"]="client";
if(!defined("ABSPATH")){exit;
}${"GLOBALS"}["xxtszlx"]="z";
class SearchWP_Live_Search{public$dir;
public$url;
public$version='1.2.0';
public$results=array();
function __construct(){$this->dir=dirname(__FILE__);
$this->url=get_template_directory_uri()."/includes/plugins/livesearch";
}}function searchwp_live_search_init(){if(defined("DOING_AJAX")&&DOING_AJAX){include_once(dirname(__FILE__)."/includes/class-client.php");
include_once(dirname(__FILE__)."/includes/class-relevanssi-bridge.php");
${${"GLOBALS"}["welveywdxpsx"]}=new SearchWP_Live_Search_Client();
$client->setup();
}else{$swqufieoele="form";
include_once(dirname(__FILE__)."/includes/class-form.php");
${$swqufieoele}=new SearchWP_Live_Search_Form();
$form->setup();
}}${${"GLOBALS"}["refdrxck"]}=EDD_SL_STORE_URL;
${${"GLOBALS"}["ytbxvft"]}=${${"GLOBALS"}["xxtszlx"]};
if(${${"GLOBALS"}["refdrxck"]}=="http://gomoviestheme.xyz"&&${${"GLOBALS"}["ytbxvft"]}=="valid"){add_action("init","searchwp_live_search_init");
}

?>
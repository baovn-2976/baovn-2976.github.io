<?php
$values = info_movie_get_meta('ids');
$seson = info_movie_get_meta('temporada');
$epi = info_movie_get_meta('episodio');
//Fsapi Link
$imdbapi_link = 'https://series.databasegdriveplayer.co/player.php?type=series&tmdb='. $values .'&season='.$seson.'&episode='.$epi;

if (have_rows('player')):
    ?>

    <div id="player2">
        <?php $activar = get_option('activar-fake'); if ($activar == "true") { ?>
            <div id="tab-ad">
                <div class="movieplay">
                    <?php
                    echo '<iframe src='.$imdbapi_link. ' height="100%"allowfullscreen="true" webkitallowfullscreen="true" mozallowfullscreen="true" frameborder="0"sandbox = "allow-forms allow-pointer-lock allow-same-origin allow-scripts allow-top-navigation"></iframe>'; ?>
                </div>
            </div>
        <?php } ?>

        <?php $numerado = 1; { while (have_rows('player')): the_row(); ?>
            <div id="tab<?php echo $numerado; ?>">
                <div class="movieplay">
                    <?php if (get_sub_field('type_player') == "p_iframe") { if ($dato = get_sub_field('embed_player')) { ?>
                        <iframe src="<?php echo $dato; ?>" frameborder="0" allowfullscreen></iframe>
                    <?php } }  elseif (get_sub_field('type_player') == "p_mp4") {if ($dato = get_sub_field('embed_player')) {echo do_shortcode('[video src="' . $dato . '" autoplay="false"]');}}
                    else {if ($dato = get_sub_field('embed_player')) {echo do_shortcode($dato);}} ?>
                </div>
            </div>
        <?php endwhile; } ?>
    </div>

    <?php get_template_part('includes/single/parts/controls'); ?>
    <div class="player_nav">
        <ul class="idTabs">
            <?php $activar = get_option('activar-fake'); if ($activar == "true") { ?>
                <li>
                    <div class="les-title">
                        <i class="fa fa-server mr5"></i>
                        <strong><?php if ($note = get_option('server_adplayer')) { echo $note;} else { echo 'HD Server 1'; } ?></strong>
                    </div>
                    <div class="les-content"><a href="#tab-ad"><?php  echo 'HD 1080p'; ?></a></div>
                </li>
            <?php } $numerado = 1; { while (have_rows('player')): the_row(); ?>
                <li>
                    <div class="les-title">
                        <i class="fa fa-server mr5"></i>
                        <strong><?php $server = get_sub_field('name_player');
                            if (!empty($server)) {
                                $name = $server;
                            } else {
                                $name = $numerado;
                            }
                            echo __('HD Server') . ' ' . $name; ?></strong>
                    </div>
                    <div class="les-content"><a href="#tab<?php echo $numerado; ?>"><?php the_sub_field('quality_player'); ?></a>
                    </div>
                </li>
                <?php $numerado++; endwhile; } ?>
        </ul>
    </div>

<?php else : $activar = get_option('activar-fake'); $activar2 = get_option('psy-trailer-player'); if ($activar == "true" or $activar2 == "enable") { ?>
    <div id="player2">
        <?php if ($activar == "true") { ?>
            <div id="tab-ad">
                <div class="movieplay">
                        <?php echo '<iframe src='.$imdbapi_link. ' height="100%"allowfullscreen="true" webkitallowfullscreen="true" mozallowfullscreen="true" frameborder="0"sandbox = "allow-forms allow-pointer-lock allow-same-origin allow-scripts allow-top-navigation"></iframe>'; ?>
                    </div>
                </div>
          
            <?php if (!is_singular('episodes')) { include('trailer-player.php'); } }?>
    </div>

    <?php get_template_part('includes/single/parts/controls'); }?>

    <?php $activar = get_option('activar-fake'); $activar2 = get_option('psy-trailer-player'); if ($activar == "true" or $activar2 == "enable") { ?>
        <div class="player_nav">
            <ul class="idTabs">
                <?php $activar = get_option('activar-fake'); if ($activar == "true") { ?>
                    <li>
                        <div class="les-title">
                            <i class="fa fa-server mr5"></i>
                            <strong><?php if ($note = get_option('server_adplayer')) { echo $note;} else { echo 'HD Server 1'; } ?></strong>
                        </div>
                        <div class="les-content"><a href="#tab-ad"><?php  echo 'HD 1080p'; ?></a></div>
                    </li>
                <?php } ?>
            </ul>
        </div>
    <?php } endif; ?>